var app = angular.module("myApp", []);
app.controller("myCtrl", [
  "$scope",
  "$http",
  function($scope, $http) {
    let proxyUrl = "https://cors-anywhere.herokuapp.com/"; //Proxy URL
    let likesLocalDb = [];
    let commentsLocalDb = [];
    let defaultName = "Subbu Swaroop";
    $scope.loadSuccess = false;
    $scope.jsondata = [];
    $scope.showAddImage = false;
    $scope.editField = false;
    $scope.aboutyou = "Make every moment count..";
    $scope.yourName = "Subbu Swaroop";
    $http({
      method: "GET",
      url: proxyUrl + "http://starlord.hackerearth.com/insta"
    }).then(
      data => {
        $scope.jsondata = data.data;
        console.log($scope.jsondata);
        $scope.loadSuccess = true;
      },
      error => {
        console.log("Error in fetching from API");
      }
    );
    //Like Button for every image
    $scope.likeButton = (event, index) => {
      let liked = event.target.classList.toggle("fa-heart");
      event.target.classList.toggle("fa-heart-o");
      if (liked == false) {
        $scope.jsondata[index].likes = $scope.jsondata[index].likes - 1;
      } else {
        $scope.jsondata[index].likes = $scope.jsondata[index].likes + 1;
      }
      likesLocalDb[index] = $scope.jsondata[index].likes;
      //Likes are stored in local storage
      localStorage.setItem("LikesStorage", JSON.stringify(likesLocalDb));
    };
    $scope.addComment = (event, index, data) => {
      if (data !== undefined && data !== "") {
        event.target.previousElementSibling.innerHTML = "You : " + data;
        commentsLocalDb[index] = data;
        //Comments are stored in local storage
        localStorage.setItem(
          "CommentsStorage",
          JSON.stringify(commentsLocalDb)
        );
        event.target.value = "";
      }
    };
    //Add Image
    $scope.uploadFile = () => {
      if ($scope.filepreview != undefined) {
        let param = {
          Image: $scope.filepreview,
          likes: 0,
          timestamp: new Date()
        };
        $scope.jsondata.unshift(param);
        alert("Image Uploaded Successsfully");
        $scope.showAddImage = false;
      } else {
        alert("Please choose a file");
      }
    };
    //Delete Image
    $scope.deleteButton = (event, index) => {
      $scope.jsondata.splice(index, 1);
      if (likesLocalDb[index]) {
        likesLocalDb.splice(index, 1);
        localStorage.setItem("LikesStorage", JSON.stringify(likesLocalDb));
      }
      if (commentsLocalDb[index]) {
        commentsLocalDb.splice(index, 1);
        localStorage.setItem(
          "CommentsStorage",
          JSON.stringify(commentsLocalDb)
        );
      }
    };
    $scope.showhideadd = () => {
      $scope.showAddImage = !$scope.showAddImage;
    };
    $scope.cancelAdd = () => {
      $scope.showAddImage = false;
    };
    $scope.editProfile = () => {
      $scope.editField = true;
    };
    $scope.savedetails = () => {
      if ($scope.yourName === "") {
        alert("Name cannot be empty");
        $scope.yourName = defaultName;
      }
      $scope.editField = false;
    };
  }
]);
//File Reader API for reading image
app.directive("fileinput", [
  function() {
    return {
      scope: {
        fileinput: "=",
        filepreview: "="
      },
      link: function(scope, element) {
        element.bind("change", function(changeEvent) {
          scope.fileinput = changeEvent.target.files[0];
          var reader = new FileReader();
          reader.onload = function(loadEvent) {
            scope.$apply(function() {
              scope.filepreview = loadEvent.target.result;
            });
          };
          reader.readAsDataURL(scope.fileinput);
        });
      }
    };
  }
]);
