import React from "react";
import { BeatLoader } from "react-spinners";

export default class LoadSpinner extends React.Component {
  render() {
    return (
      <div className="loadSpinner">
        <BeatLoader
          sizeUnit={"px"}
          size={50}
          color={"#123abc"}
          loading={this.props.showspin}
        />
      </div>
    );
  }
}
