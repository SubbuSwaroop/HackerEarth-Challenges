import React, { Component } from "react";
import { Button } from "reactstrap";
export default class LoadButton extends Component {
  render() {
    return (
      <div className="loadButton">
        <div>
          <Button onClick={this.props.clickHandle}>Click</Button>
        </div>
      </div>
    );
  }
}
