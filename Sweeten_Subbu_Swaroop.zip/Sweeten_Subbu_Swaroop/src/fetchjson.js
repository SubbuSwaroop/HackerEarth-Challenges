import React, { Component } from "react";
import Pagination from "react-js-pagination";
import { Input } from "reactstrap";
import {
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";
class JsonData extends Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = {
      visible: false,
      jsondata: [],
      noOfItems: 0,
      pageCount: 0,
      currentPage: 1,
      itemsPerPage: 10,
      activePage: 1,
      dropdownOpen: false,
      sortAsc: false,
      filterValues: [],
      jsondataFilter: [],
      filterGenre: "",
      filterCountry: "",
      filterLang: "",
      filterBudget: "",
      filterYear: ""
    };
  }

  componentDidMount() {
    async function getdata() {
      var proxyurl = "https://cors-anywhere.herokuapp.com/"; // I have used a proxy here as it was giving a CORS error when trying to access the API directly.
      var url = "http://starlord.hackerearth.com/movies";
      let response = await fetch(proxyurl + url);
      let jsondata = await response.json();
      return jsondata;
    }
    getdata().then(data => {
      let filterValues = [];
      let params = {};
      this.setState({ jsondata: data, jsondataFilter: data, visible: true });
      if (this.state.jsondata.length > 0) {
        this.props.isData();
        this.setState({
          noOfItems: this.state.jsondata.length
        });
        this.state.jsondata.map((data, index) => {
          params = {
            name: data.movie_title,
            index: index
          };
          return filterValues.push(params);
        });
        this.setState({ filterValues }, () => {
          console.log(this.state.filterValues);
        });
      }
    });
  }
  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }
  handlePageChange = pageNumber => {
    this.setState({
      currentPage: Number(pageNumber),
      activePage: Number(pageNumber)
    });
  };
  sortMovies = event => {
    let sortedarr = [];
    if (event.target.value === "true") {
      sortedarr = this.state.jsondata.sort((a, b) => {
        if (a.movie_title < b.movie_title) return -1;
        if (a.movie_title > b.movie_title) return 1;
        return 0;
      });
    } else {
      sortedarr = this.state.jsondata.sort((a, b) => {
        if (a.movie_title < b.movie_title) return -1;
        if (a.movie_title > b.movie_title) return 1;
        return 0;
      });
      sortedarr.reverse();
    }
    this.setState({ jsondata: sortedarr });
  };
  commonFilter = event => {
    let filtereddata = [];
    let varName = event.target.id;
    let varValue = event.target.value;
    this.setState({ [event.target.id]: event.target.value, currentPage: 1 });
    if (varName === "filterGenre") {
      filtereddata = this.state.jsondataFilter.filter(data => {
        return data.genres.toLowerCase().includes(varValue.toLowerCase());
      });
    } else if (varName === "filterLang") {
      filtereddata = this.state.jsondataFilter.filter(data => {
        return data.language.toLowerCase().includes(varValue.toLowerCase());
      });
    } else if (varName === "filterCountry") {
      filtereddata = this.state.jsondataFilter.filter(data => {
        return data.country.toLowerCase().includes(varValue.toLowerCase());
      });
    } else if (varName === "filterBudget") {
      filtereddata = this.state.jsondataFilter.filter(data => {
        return data.budget.toLowerCase().includes(varValue.toLowerCase());
      });
    } else if (varName === "filterYear") {
      filtereddata = this.state.jsondataFilter.filter(data => {
        return data.title_year.toLowerCase().includes(varValue.toLowerCase());
      });
    } else if (varName === "") {
      filtereddata = this.state.jsondataFilter;
    }
    this.setState({ jsondata: filtereddata });
  };
  render() {
    const { currentPage, itemsPerPage, jsondata } = this.state;
    const lastIndex = currentPage * itemsPerPage;
    const firstIndex = lastIndex - itemsPerPage;
    const currentPageData = jsondata.slice(firstIndex, lastIndex);
    const renderPageData = currentPageData.map((element, index) => {
      return (
        <li
          key={
            parseInt(element.title_year) +
            parseInt(element.movie_imdb_link.substring(28, 35)) +
            index
          }
        >
          <div className="grid-item">
            <img
              src="https://www.goread.com/media/cache/ef/8f/ef8f5daeac0b49c9e0d12dbbd40a1ce7.jpg"
              alt="Beers"
              style={{ width: "100%" }}
            />
            <hr />
            <h6>
              <b>
                {element.movie_title} - ({element.title_year}) (
                {element.language}) ({element.content_rating})
              </b>
            </h6>
            <p>
              <b>Actors : </b>
              {element.actor_1_name} , {element.actor_2_name}
            </p>
            <p>
              <b>Country : </b>
              {element.country}
            </p>
            <p>
              <b>Directed By : </b>
              {element.director_name}
            </p>
            <p>
              <b>Genre : </b>
              {element.genres}
            </p>
            <p>
              <b>Budget : </b>
              {element.budget}
            </p>
          </div>
        </li>
      );
    });
    return (
      <div className="movieDiv">
        {this.state.visible === true ? (
          <div className="mainDiv">
            <div className="filterdiv">
              <div>
                <ButtonDropdown
                  isOpen={this.state.dropdownOpen}
                  toggle={this.toggle}
                >
                  <DropdownToggle caret color="danger">
                    Sort
                  </DropdownToggle>
                  <DropdownMenu>
                    <DropdownItem value="true" onClick={this.sortMovies}>
                      Sort A to Z
                    </DropdownItem>
                    <DropdownItem value="false" onClick={this.sortMovies}>
                      Sort Z to A
                    </DropdownItem>
                  </DropdownMenu>
                </ButtonDropdown>
              </div>
              <div className="inputfilter">
                <label for="filterGenre">Genre</label>
                <Input
                  type="text"
                  id="filterGenre"
                  value={this.filterGenre}
                  onChange={this.commonFilter}
                />
              </div>
              <div className="inputfilter">
                <label for="filterCountry">Country</label>
                <Input
                  type="text"
                  id="filterCountry"
                  value={this.filterGenre}
                  onChange={this.commonFilter}
                />
              </div>
              <div className="inputfilter">
                <label for="filterLang">Language</label>
                <Input
                  type="text"
                  id="filterLang"
                  value={this.filterGenre}
                  onChange={this.commonFilter}
                />
              </div>
              <div className="inputfilter">
                <label for="filterBudget">Budget</label>
                <Input
                  type="text"
                  id="filterBudget"
                  value={this.filterGenre}
                  onChange={this.commonFilter}
                />
              </div>
              <div className="inputfilter">
                <label for="filterYear">Title Year</label>
                <Input
                  type="text"
                  id="filterYear"
                  value={this.filterGenre}
                  onChange={this.commonFilter}
                />
              </div>
              <div>
                <Pagination
                  hideFirstLastPages
                  activePage={this.state.activePage}
                  itemsCountPerPage={10}
                  totalItemsCount={this.state.jsondata.length}
                  pageRangeDisplayed={8}
                  onChange={this.handlePageChange}
                />
              </div>
            </div>
            <div className="maindiv">
              <ul className=" grid-container">{renderPageData}</ul>
            </div>{" "}
          </div>
        ) : (
          <div />
        )}
      </div>
    );
  }
}

export default JsonData;
