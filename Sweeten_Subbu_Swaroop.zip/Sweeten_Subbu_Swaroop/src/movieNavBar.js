import React, { Component } from "react";
import { Navbar, Nav, NavItem, NavbarBrand } from "reactstrap";
import SwitchTheme from "./switchtheme";

export default class Example extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
    return (
      <div>
        <Navbar className="navbarClass" expand="md">
          <NavbarBrand className="navbarBrand" href="/">
            Movie Analysis
          </NavbarBrand>
          <Nav className="ml-auto" navbar>
            <NavItem>
              <SwitchTheme />
            </NavItem>
          </Nav>
        </Navbar>
      </div>
    );
  }
}
