import React, { Component } from "react";
import NavbarMovie from "./movieNavBar";
import Jsondata from "./fetchjson";
import LoadSpinner from "./LoadSpinner";

import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { loading: true };
  }
  dataCheck = () => {
    this.setState({ loading: false });
  };
  render() {
    return (
      <div className="App">
        <NavbarMovie />
        <LoadSpinner showspin={this.state.loading} />
        <Jsondata isData={this.dataCheck} />
      </div>
    );
  }
}

export default App;
