var jsondata = [];
var beerstylesarr = [];
var uniquebeerstylearr = [];
var uniquebeernames = [];
var sortAsc = true;
var cartItems = [];
var altereddata = [];
$(document).ready(function() {
  async function getdata() {
    var proxyurl = "https://cors-anywhere.herokuapp.com/"; // I have used a proxy here as it was giving a CORS error when trying to access the API directly.
    var url = "http://starlord.hackerearth.com/beercraft";
    let response = await fetch(proxyurl + url);
    let jsondata = await response.json();
    return jsondata;
  }
  getdata().then(data => {
    jsondata = data;
    altereddata = data;
    jsondata.forEach(data => {
      beerstylesarr.push(data.style);
    });
    jsondata.forEach(data => {
      uniquebeernames.push(data.name);
    });
    uniquebeerstylearr = [...new Set(beerstylesarr)];
    $("#beerstyles").autocomplete({
      source: uniquebeerstylearr
    });
    $("#searchedBeerName").autocomplete({
      source: uniquebeernames
    });
    displaydata(data);
    recommendedBeers(data);
  });
});
displaydata = data => {
  $.each(data, function(index, data1) {
    let alcoholContent = data1.abv == "" ? "0" : data1.abv;
    let beerinfo =
      "<div class='beerbox'>" +
      "<img src='https://cdn2.justwineapp.com/assets/article/2017/05/photo-pint-beer-free-stock-image-royalty-free-instagram-social-media.jpg' alt='Beers' style='width:100%'>" +
      "<div>" +
      "<h4 class='grid-item'><b>" +
      data1.name +
      "</b></h4>" +
      "<p>" +
      alcoholContent +
      " Alcohol Content</p>" +
      "<p>" +
      data1.style +
      " style</p>" +
      "<p>" +
      data1.ounces +
      " Ounces </p>" +
      "<button class='addcart btn btn-success' onclick='addToCart(\"" +
      data1.name +
      "\")'>Add to Cart</button>" +
      "</div>";
    $(".loadButton").remove();
    $(".beercontainer").append(beerinfo);
  });
};
recommendedBeers = data => {
  let recommended = data.filter(data1 => {
    return parseFloat(data1.abv) >= 0.1;
  });
  recommended.forEach((data1, index) => {
    let alcoholContent = data1.abv == "" ? "0" : data1.abv;
    let beerinfo = "";
    if (index == 0) {
      beerinfo = "<div class='item active containerBeer'>";
    } else {
      beerinfo = "<div class='item containerBeer'>";
    }
    beerinfo +=
      "<div>" +
      "<h4><b>" +
      data1.name +
      "</b></h4>" +
      "<p>" +
      alcoholContent +
      " Alcohol Content</p>" +
      "<p>" +
      data1.style +
      " style</p>" +
      "<p>" +
      data1.ounces +
      " Ounces </p>" +
      "</div>";
    $(".carousel-inner").append(beerinfo);
  });
};
searchBeer = () => {
  let filtereddata = [];
  let searchtext = document.getElementById("searchedBeerName").value;
  if (searchtext == "" || searchtext == null) {
    filtereddata = jsondata;
  } else {
    filtereddata = jsondata.filter(data => {
      return data.name.toLowerCase().includes(searchtext.toLowerCase());
    });
  }
  altereddata = filtereddata;
  uniquebeernames = [];
  beerstylesarr = [];
  uniquebeerstylearr = [];
  altereddata.forEach(data => {
    uniquebeernames.push(data.name);
  });
  altereddata.forEach(data => {
    beerstylesarr.push(data.style);
  });
  $("#searchedBeerName").autocomplete({
    source: uniquebeernames
  });
  altereddata.forEach(data => {
    beerstylesarr.push(data.style);
  });
  uniquebeerstylearr = [...new Set(beerstylesarr)];
  $(".beerbox").remove();
  displaydata(filtereddata);
};
filterstyle = () => {
  let filtereddata = [];
  let searchtext = document.getElementById("beerstyles").value;
  if (searchtext == "" || searchtext == null) {
    filtereddata = jsondata;
  } else {
    filtereddata = jsondata.filter(function(data) {
      return data.style.toLowerCase().includes(searchtext.toLowerCase());
    });
  }
  altereddata = filtereddata;
  uniquebeernames = [];
  altereddata.forEach(data => {
    uniquebeernames.push(data.name);
  });
  $("#searchedBeerName").autocomplete({
    source: uniquebeernames
  });
  $(".beerbox").remove();
  displaydata(filtereddata);
};
sortBeer = () => {
  let sortedarr = [];
  if (sortAsc == true) {
    sortedarr = altereddata.sort((a, b) => {
      if (a.abv < b.abv) return -1;
      if (a.abv > b.abv) return 1;
      return 0;
    });
    sortAsc = false;
  } else {
    sortedarr = altereddata.sort((a, b) => {
      if (a.abv < b.abv) return -1;
      if (a.abv > b.abv) return 1;
      return 0;
    });
    sortedarr.reverse();
    sortAsc = true;
  }
  $(".beerbox").remove();
  displaydata(sortedarr);
  if (sortAsc == false) {
    alert("Sorted Ascending");
  } else {
    alert("Sorted Descending");
  }
};
addToCart = obj => {
  let cartlist = "";
  alert(obj + " added to cart");
  cartItems.push(obj);
  sessionStorage.setItem("Cart", cartItems);
  cartItems.forEach(data => {
    cartlist += "<li>" + data + "</li>";
  });
  var modal =
    "<div class='modal fade cartmodalbox' id='myModal' role='dialog'><div class='modal-dialog modal-sm'><div class='modal-content'><div class='modal-header'>" +
    "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
    "<h4 class='modal-title'>Beer Cart</h4></div>" +
    "<div class='modal-body'>" +
    "<ul>" +
    cartlist +
    "</ul>" +
    "</div>" +
    "<div class='modal-footer'><button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
    "</div></div></div></div>";
  $(".cartmodalbox").remove();
  $(".cartModal").append(modal);
};
