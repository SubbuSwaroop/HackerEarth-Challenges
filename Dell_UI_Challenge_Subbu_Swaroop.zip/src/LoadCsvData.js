import React, { Component } from "react";
import GetCsv from "get-csv";
import FontAwesome from "react-fontawesome";
import "bootstrap/dist/css/bootstrap.css";
import Autocomplete from "react-autocomplete";
import Pagination from "react-js-pagination";
import {
  Jumbotron,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Dropdown,
  Row,
  Col
} from "reactstrap";
class LoadCsvData extends Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.toggleFilter = this.toggleFilter.bind(this);
    this.state = {
      csvData: [],
      loaded: false,
      searchNames: [],
      showNames: [],
      autocompletevalue: "",
      csvDataFilter: [],
      currentPage: 1,
      itemsPerPage: 4,
      activePage: 1,
      dropdownOpen: false,
      cuisineFilter: []
    };
  }
  componentDidMount() {
    async function getData() {
      let proxyurl = "https://cors-anywhere.herokuapp.com/"; // Proxy URL
      let url = "http://hck.re/RQfq5X";
      let response = await GetCsv(proxyurl + url);
      return response;
    }
    getData().then(data => {
      this.setState({
        csvData: data,
        csvDataFilter: data,
        loaded: true
      });
      let searchnames = [];
      let cuisines = [];
      this.state.csvData.map((data, index) => {
        let param = {
          name: data.Name,
          index: index
        };
        let temparr = [];
        let temparr1 = [];
        temparr = data["Cuisine Style"]
          .substring(1, data["Cuisine Style"].length - 1)
          .replace(/'/g, "")
          .split(",");
        temparr1 = temparr.map(str => str.trim());
        searchnames.push(param);
        return cuisines.push(temparr1.join());
      });
      let unique = cuisines.join().split(",");
      let uniqueCuisine = unique.filter((value, index, self) => {
        return self.indexOf(value) === index;
      });
      this.setState({
        showNames: searchnames.slice(0, 200),
        searchNames: searchnames,
        cuisineFilter: uniqueCuisine
      });
    });
  }
  toggle = () => {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  };
  toggleFilter = () => {
    this.setState({
      dropdownOpenFilter: !this.state.dropdownOpenFilter
    });
  };
  //Search
  selectInput = val => {
    this.setState({ autocompletevalue: val, currentPage: 1 });
    let filtereddata = [];
    if (val === "") {
      this.setState({
        csvData: this.state.csvDataFilter
      });
    } else {
      filtereddata = this.state.csvDataFilter.filter(data => {
        return data.Name.toLowerCase().includes(val.toLowerCase());
      });
      this.setState({ csvData: filtereddata });
    }
  };
  inputChange = event => {
    let tempsearch = [];
    let val = event.target.value;
    this.setState({
      autocompletevalue: val,
      currentPage: 1
    });
    if (val !== "" && val.length > 3) {
      tempsearch = this.state.searchNames.filter(data => {
        return data.name.toLowerCase().includes(val.toLowerCase());
      });
      this.setState({
        showNames: tempsearch
      });
      this.filterData(event.target.value);
    } else {
      this.setState({
        showNames: this.state.searchNames.slice(0, 200)
      });
      this.filterData(event.target.value);
    }
  };
  filterData = value => {
    let filtereddata = [];
    if (value === "") {
      filtereddata = this.state.csvDataFilter;
    } else {
      filtereddata = this.state.csvDataFilter.filter(data => {
        return data.Name.toLowerCase().includes(value.toLowerCase());
      });
    }
    this.setState({ csvData: filtereddata });
  };
  //Pagination
  handlePageChange = pageNumber => {
    this.setState({
      currentPage: Number(pageNumber),
      activePage: Number(pageNumber)
    });
  };
  //Sort
  sortRestaurants = event => {
    let sortedarr = [];
    let tempOne = 0;
    let tempTwo = 0;
    sortedarr = this.state.csvData.sort((a, b) => {
      if (a.Rating === "") {
        tempOne = 0;
      } else {
        tempOne = parseFloat(a.Rating);
      }
      if (b.Rating === "") {
        tempTwo = 0;
      } else {
        tempTwo = parseFloat(b.Rating);
      }
      if (tempOne < tempTwo) {
        return -1;
      }
      if (tempOne > tempTwo) {
        return 1;
      }
      return 0;
    });
    if (event.target.value === "true") {
      this.setState({
        csvData: sortedarr,
        currentPage: 1,
        autocompletevalue: ""
      });
    } else {
      sortedarr.reverse();
      this.setState({ csvData: sortedarr, currentPage: 1 });
    }
  };
  //Filter
  filterCuisine = event => {
    let tempfilter = this.state.csvDataFilter.filter(data => {
      return data["Cuisine Style"]
        .toLowerCase()
        .includes(event.target.value.toLowerCase());
    });
    this.setState({
      csvData: tempfilter,
      currentPage: 1,
      autocompletevalue: ""
    });
    alert("Found " + tempfilter.length + " restaurants");
  };
  render() {
    const { currentPage, itemsPerPage, cuisineFilter } = this.state;
    const lastIndex = currentPage * itemsPerPage;
    const firstIndex = lastIndex - itemsPerPage;
    const currentPageData = this.state.csvData.slice(firstIndex, lastIndex);
    const cuisineFilterItems = cuisineFilter.map((data, index) => {
      return (
        <DropdownItem key={index} value={data} onClick={this.filterCuisine}>
          {data}
        </DropdownItem>
      );
    });
    const restaurantTypes = currentPageData.map((data, index) => {
      return (
        <div className="grid-item" key={index}>
          <div className="imagediv">
            <img
              src="https://us.123rf.com/450wm/jehsomwang/jehsomwang1503/jehsomwang150300160/37725948-stock-vector-illustration-of-isolated-restaurant-vector.jpg?ver=6"
              alt="Restaurant"
              className="imageClass"
            />
          </div>
          <div className="detailsdiv">
            <div className="insideDetails">
              <div>
                <p>
                  <b>{data.Name}</b>
                </p>
                <p>
                  {data["Cuisine Style"]
                    .substring(1, data["Cuisine Style"].length - 2)
                    .replace(/'/g, " ")}
                </p>
                <p>{data.City}</p>
              </div>
              <div>
                <span className="ratingClass">
                  <FontAwesome name="star" style={{ color: "#FFDF00" }} />{" "}
                  {data.Rating}
                </span>
              </div>
            </div>
          </div>
          <div className="reviewDiv">
            <span className="userReviews">
              {data["Number of Reviews"] === ""
                ? "0"
                : data["Number of Reviews"]}{" "}
              Reviews
            </span>
          </div>
          <div className="reviewDiv" />
        </div>
      );
    });
    return (
      <div>
        <div className="contentDiv">
          <Jumbotron className="jumbotron">
            <h3>European Restaurants</h3>
          </Jumbotron>
          <Row className="searchrow">
            <Col xs="12" sm="5" md="6" lg="7" className="commonCol">
              <span className="searchIcon">
                <FontAwesome name="search" />
              </span>
              <Autocomplete
                inputProps={{
                  placeholder: "Search by name"
                }}
                getItemValue={item => item.name}
                shouldItemRender={(item, value) =>
                  item.name.toLowerCase().indexOf(value.toLowerCase()) > -1
                }
                items={this.state.showNames}
                value={this.state.autocompletevalue}
                renderItem={(item, isHighlighted) => (
                  <div
                    key={item.index}
                    style={{
                      background: isHighlighted ? "lightgray" : "white"
                    }}
                  >
                    {item.name}
                  </div>
                )}
                onSelect={this.selectInput}
                onChange={this.inputChange}
              />
            </Col>
            <Col xs="6" sm="2" md="3" lg="3" className="commonCol">
              <ButtonDropdown
                isOpen={this.state.dropdownOpen}
                toggle={this.toggle}
              >
                <DropdownToggle caret color="danger">
                  Sort
                </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem value="true" onClick={this.sortRestaurants}>
                    Lowest To Highest
                  </DropdownItem>
                  <DropdownItem value="false" onClick={this.sortRestaurants}>
                    Highest To Lowest
                  </DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>
            </Col>
            <Col xs="1" sm="1" md="1" lg="1" className="commonCol">
              <Dropdown
                isOpen={this.state.dropdownOpenFilter}
                toggle={this.toggleFilter}
                direction="left"
              >
                <DropdownToggle
                  tag="span"
                  onClick={this.toggleFilter}
                  data-toggle="dropdown"
                  aria-expanded={this.state.dropdownOpenFilter}
                >
                  <FontAwesome name="filter" size="2x" className="filterIcon" />
                </DropdownToggle>
                <DropdownMenu
                  modifiers={{
                    setMaxHeight: {
                      enabled: true,
                      order: 890,
                      fn: data => {
                        return {
                          ...data,
                          styles: {
                            ...data.styles,
                            overflow: "auto",
                            maxHeight: 100
                          }
                        };
                      }
                    }
                  }}
                >
                  {cuisineFilterItems}
                </DropdownMenu>
              </Dropdown>
            </Col>
          </Row>
          {this.state.loaded === false ? (
            <div className="loadingDiv">
              <FontAwesome
                name="spinner"
                className="loadingSpinner"
                size="3x"
              />
            </div>
          ) : (
            <div className="grid-container">{restaurantTypes}</div>
          )}
        </div>
        {this.state.loaded === true ? (
          <Pagination
            activeClass="active"
            activePage={this.state.activePage}
            itemsCountPerPage={4}
            totalItemsCount={this.state.csvData.length}
            pageRangeDisplayed={8}
            onChange={this.handlePageChange}
          />
        ) : (
          <div />
        )}
      </div>
    );
  }
}

export default LoadCsvData;
